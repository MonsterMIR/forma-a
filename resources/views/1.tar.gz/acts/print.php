<?php
/**
 * print.php — Форма А / Form A
 * v3: чёткая печать, НДС 0% для international, валидация
 */

$supervisorName = $act['created_by_fullname'] ?? $act['created_by_username'] ?? '—';
$supervisorDate = format_date($act['act_date'] ?? $act['created_at'], 'd.m.Y');
$approvedName   = $act['approved_by_fullname'] ?? $act['approved_by_username'] ?? null;
$approvedDate   = !empty($act['approved_at']) ? format_date($act['approved_at'], 'd.m.Y') : null;

$actTitle    = e($act['act_number']);
$flightLabel = e($act['flight_number']) . ' ' . format_date($act['flight_date'], 'd.m.Y')
             . ' (' . e($act['origin_iata'] ?? '?') . '→' . e($act['destination_iata'] ?? '?') . ')';

$isIntl = ($act['route_type'] === 'international');
$vatLabel = $isIntl ? 'НДС 0% / VAT 0%' : 'НДС 12% / VAT 12%';
$cur = e($act['currency_code']);

// Verification code + QR
$verifyCode = act_verify_code(
    $act['act_number'],
    $act['act_date'],
    (float)$act['total_amount_with_vat']
);

// QR-код: ссылка на публичную страницу верификации
$appUrl  = rtrim($_ENV['APP_URL'] ?? 'https://forma.tvtairport.uz', '/');
$verifyUrl = $appUrl . '/verify/' . $verifyCode;

// Генерируем QR через qrencode (установлен на сервере)
$qrBase64 = null;
$qrPath   = sys_get_temp_dir() . '/qr_' . $verifyCode . '.png';
if (!file_exists($qrPath)) {
    $cmd = sprintf(
        'qrencode -o %s -s 4 -m 1 %s 2>/dev/null',
        escapeshellarg($qrPath),
        escapeshellarg($verifyUrl)
    );
    @shell_exec($cmd);
}
if (file_exists($qrPath)) {
    $qrBase64 = 'data:image/png;base64,' . base64_encode(file_get_contents($qrPath));
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
<meta charset="UTF-8">
<title>Форма А — <?= $actTitle ?> — VCD-<?= $verifyCode ?></title>
<style>
/* ================================================
   BASE — screen and print
   ================================================ */
* { box-sizing: border-box; margin: 0; padding: 0; }

body {
    font-family: Arial, Helvetica, sans-serif;
    font-size: 9pt;
    color: #000;
    background: #fff;
    -webkit-print-color-adjust: exact;
    print-color-adjust: exact;
}

.page {
    width: 210mm;
    min-height: 297mm;
    margin: 0 auto;
    padding: 8mm 10mm;
}

/* ── TITLE ─────────────────────────────── */
.form-title {
    text-align: center;
    font-size: 13pt;
    font-weight: bold;
    border: 2pt solid #000;
    padding: 5px 10px;
    margin-bottom: 5px;
    background: #1a3a6b;
    color: #fff;
    letter-spacing: 0.5px;
}

/* ── ACT META ───────────────────────────── */
.act-meta {
    display: flex;
    justify-content: space-between;
    align-items: flex-end;
    border-bottom: 2pt solid #000;
    padding-bottom: 4px;
    margin-bottom: 5px;
}
.act-meta .act-num  { font-size: 12pt; font-weight: bold; color: #000; }
.act-meta .act-sub  { font-size: 8.5pt; color: #333; margin-top: 2px; }
.act-meta .act-date { font-size: 9pt; font-weight: bold; }
.act-meta .act-status {
    font-size: 8.5pt; font-weight: bold;
    padding: 2px 8px; border: 1.5pt solid #000;
    background: <?= $act['status'] === 'approved' ? '#006400' : '#8b0000' ?>;
    color: #fff;
}

/* ── FLIGHT TYPE ────────────────────────── */
.ftype {
    width: 100%; border-collapse: collapse;
    margin-bottom: 5px; font-size: 8.5pt;
}
.ftype td { border: 1pt solid #000; padding: 2px 5px; text-align: center; }
.ftype td.lbl {
    text-align: left; font-weight: bold; width: 42%;
    background: #e8ecf5; color: #000;
}
.ftype td.chk {
    background: #c8e6c9; font-weight: bold; color: #000;
}

/* ── FLIGHT INFO ────────────────────────── */
.info-tbl { width: 100%; border-collapse: collapse; margin-bottom: 5px; font-size: 8.5pt; }
.info-tbl td { border: 1pt solid #000; padding: 2.5px 6px; vertical-align: middle; }
.info-tbl .sec-hdr {
    background: #1a3a6b; color: #fff;
    font-weight: bold; font-size: 9pt;
    text-align: center; padding: 3px;
}
.info-tbl .lbl { width: 52%; background: #f0f3f8; font-style: italic; color: #000; }
.info-tbl .val { font-weight: bold; color: #000; }

/* ── SERVICES TABLE ─────────────────────── */
.svc-tbl {
    width: 100%; border-collapse: collapse;
    margin-bottom: 4px; font-size: 8pt;
    table-layout: fixed;
}
.svc-tbl colgroup col.col-name  { width: 44%; }
.svc-tbl colgroup col.col-rate  { width: 10%; }
.svc-tbl colgroup col.col-qty   { width:  8%; }
.svc-tbl colgroup col.col-unit  { width:  9%; }
.svc-tbl colgroup col.col-amt   { width: 15%; }
.svc-tbl colgroup col.col-total { width: 14%; }

.svc-tbl th {
    border: 1.5pt solid #000;
    padding: 4px 3px;
    text-align: center;
    background: #1a3a6b;
    color: #fff;
    font-size: 8pt;
    vertical-align: middle;
    line-height: 1.3;
    font-weight: bold;
}
.svc-tbl td {
    border: 1pt solid #000;
    padding: 2.5px 3px;
    vertical-align: middle;
    word-wrap: break-word;
    overflow-wrap: break-word;
}
.svc-tbl td.name { font-size: 8pt; line-height: 1.2; }
.svc-tbl td.num  { text-align: right; font-size: 8pt; }
.svc-tbl td.ctr  { text-align: center; font-size: 7.5pt; color: #000; }

/* Category row */
.svc-tbl tr.cat-row td {
    background: #d4ddf0;
    font-weight: bold;
    font-size: 8.5pt;
    color: #000;
    border-top: 1.5pt solid #000;
    padding: 3px 5px;
}

/* Data rows */
.svc-tbl tr.data-row td { background: #fff; }
.svc-tbl tr.data-row.even td { background: #f5f7fc; }

/* VAT row */
.svc-tbl tr.vat-row td {
    background: #fff9e6;
    font-weight: bold;
    font-size: 8.5pt;
    border-top: 1.5pt solid #000;
}

/* TOTAL row — most important */
.svc-tbl tr.total-row td {
    background: #1a3a6b;
    color: #fff;
    font-weight: bold;
    font-size: 11pt;
    border: 2pt solid #000;
    padding: 6px 4px;
}
.svc-tbl tr.total-row td.num {
    font-size: 12pt;
    color: #ffe57f;
    font-weight: bold;
}

/* ── NOTE ───────────────────────────────── */
.note {
    border: 1pt solid #000; padding: 4px 7px;
    font-size: 8pt; margin-bottom: 7px;
    background: #fafafa;
}

/* ── APPROVED ───────────────────────────── */
.approved-banner {
    font-size: 8.5pt; margin-bottom: 6px;
    background: #c8e6c9; border: 1pt solid #000;
    padding: 3px 8px; font-weight: bold; color: #000;
}

/* ── SIGNATURES ─────────────────────────── */
.sigs { display: flex; justify-content: space-between; gap: 15mm; margin-top: 8px; }
.sig { flex: 1; }
.sig .sig-title {
    font-weight: bold; font-size: 8.5pt;
    border-bottom: 1.5pt solid #000; padding-bottom: 2px; margin-bottom: 4px;
    color: #000;
}
.sig .row { display: flex; align-items: flex-end; margin-top: 12px; gap: 5px; }
.sig .row-lbl { font-size: 7.5pt; color: #000; white-space: nowrap; min-width: 55px; }
.sig .row-line { flex: 1; border-bottom: 1pt solid #000; }
.sig .row-val { font-size: 8pt; font-weight: bold; padding-bottom: 1px; color: #000; }

/* ── FOOTER ─────────────────────────────── */
.footer {
    margin-top: 8px; font-size: 7pt; color: #000;
    border-top: 1pt solid #000; padding-top: 3px;
    display: flex; justify-content: space-between;
}

/* ── PRINT CONTROLS (screen only) ───────── */
.controls {
    position: fixed; top: 10px; right: 10px;
    display: flex; gap: 8px; z-index: 999;
}
.controls a, .controls button {
    padding: 7px 14px; font-size: 12px; cursor: pointer;
    border-radius: 4px; border: none; text-decoration: none; display: inline-block;
}
.btn-print { background: #1a3a6b; color: #fff; font-weight: bold; }
.btn-back  { background: #555; color: #fff; }

/* ================================================
   PRINT MEDIA — override for crisp output
   ================================================ */
@media print {
    .controls { display: none !important; }

    /* Убираем шапку и подвал браузера (дата, URL, номер страницы) */
    @page {
        margin-top: 8mm;
        margin-bottom: 8mm;
        margin-left: 8mm;
        margin-right: 8mm;
    }

    body {
        font-size: 8.5pt;
        color: #000 !important;
        -webkit-print-color-adjust: exact;
        print-color-adjust: exact;
    }
    .page { padding: 0; width: 100%; }

    /* Force all borders black and solid */
    table, th, td { border-color: #000 !important; }

    /* Force backgrounds to print */
    .form-title        { background: #1a3a6b !important; color: #fff !important; }
    .info-tbl .sec-hdr { background: #1a3a6b !important; color: #fff !important; }
    .svc-tbl th        { background: #1a3a6b !important; color: #fff !important; }
    .svc-tbl tr.cat-row td { background: #d4ddf0 !important; color: #000 !important; }
    .svc-tbl tr.data-row.even td { background: #f5f7fc !important; }
    .svc-tbl tr.vat-row td { background: #fff9e6 !important; font-weight: bold !important; }
    .svc-tbl tr.total-row td {
        background: #1a3a6b !important;
        color: #fff !important;
        font-size: 11pt !important;
        font-weight: bold !important;
    }
    .svc-tbl tr.total-row td.num { color: #ffe57f !important; font-size: 12pt !important; }
    .info-tbl .lbl     { background: #f0f3f8 !important; }
    .ftype td.chk      { background: #c8e6c9 !important; }
    .ftype td.lbl      { background: #e8ecf5 !important; }
    .approved-banner   { background: #c8e6c9 !important; }
    .act-meta .act-status {
        background: <?= $act['status'] === 'approved' ? '#006400' : '#8b0000' ?> !important;
        color: #fff !important;
    }

    /* Prevent row breaks in important places */
    tr.total-row, tr.vat-row { page-break-inside: avoid; }
    .signatures, .sigs { page-break-inside: avoid; }
}
</style>
</head>
<body>

<div class="controls">
    <a class="btn-back" href="/acts/<?= (int)$act['id'] ?>">← Назад</a>
    <button class="btn-print" onclick="window.print()">🖨 Печать / PDF</button>
</div>

<div class="page">

<!-- TITLE -->
<div class="form-title">SERVICE Form &nbsp;/&nbsp; Форма Услуг &laquo;А&raquo;</div>

<!-- ACT META -->
<div class="act-meta">
    <div>
        <div class="act-num">Акт № <?= $actTitle ?></div>
        <div class="act-sub">Рейс / Flight: <strong><?= $flightLabel ?></strong></div>
    </div>
    <div class="act-date">Дата / Date: <?= format_date($act['act_date'], 'd.m.Y') ?></div>
    <div><span class="act-status"><?= strtoupper($act['status']) ?></span></div>
</div>

<!-- FLIGHT TYPE -->
<?php $rt = $act['route_type'] ?? ''; $op = $act['operation_type'] ?? ''; ?>
<table class="ftype">
    <tr>
        <td class="lbl">Number and purpose of flight / Номер рейса и цель полёта:</td>
        <td class="<?= $rt==='domestic'      ? 'chk' : '' ?>">Domestic / Внутренний</td>
        <td class="<?= $rt==='international' ? 'chk' : '' ?>">International / Международный</td>
        <td class="<?= $op==='arrival'       ? 'chk' : '' ?>">Arrival / Прилёт</td>
        <td class="<?= $op==='departure'     ? 'chk' : '' ?>">Departure / Вылет</td>
    </tr>
</table>

<!-- FLIGHT INFO -->
<table class="info-tbl">
    <tr><td class="sec-hdr" colspan="2">Flight details / Информация по рейсу</td></tr>
    <tr><td class="lbl">Air company / Авиакомпания</td>
        <td class="val"><?= e($act['airline_name']) ?> <small>(<?= e($act['airline_iata'] ?? '') ?>)</small></td></tr>
    <tr><td class="lbl">Flight number / Номер рейса</td>
        <td class="val"><?= e($act['flight_number']) ?></td></tr>
    <tr><td class="lbl">Aircraft registration / Регистрация ВС</td>
        <td class="val"><?= e($act['aircraft_registration'] ?? '—') ?></td></tr>
    <tr><td class="lbl">Type of aircraft / Тип ВС</td>
        <td class="val"><?= e($act['aircraft_type'] ?? '—') ?></td></tr>
    <tr><td class="lbl">Route / Маршрут</td>
        <td class="val"><?= e($act['origin_iata'] ?? '—') ?> → <?= e($act['destination_iata'] ?? '—') ?></td></tr>
    <tr><td class="lbl">Date of flight / Дата рейса</td>
        <td class="val"><?= format_date($act['flight_date'], 'd.m.Y') ?></td></tr>
    <tr><td class="lbl">Settlement currency / Валюта расчёта</td>
        <td class="val"><?= $cur ?> — <?= e($act['currency_name']) ?></td></tr>
    <?php if (!empty($act['cb_rate'])): ?>
    <tr><td class="lbl">CB Rate / Курс ЦБ (USD → <?= $cur ?>)</td>
        <td class="val"><?= number_format((float)$act['cb_rate'], 2, '.', ' ') ?></td></tr>
    <?php endif; ?>
    <tr><td class="lbl">VAT / НДС</td>
        <td class="val"><?= $isIntl ? '<span style="color:#006400;font-weight:bold">0% — International flight</span>' : '<span style="color:#8b0000;font-weight:bold">12% — Domestic flight</span>' ?></td></tr>
</table>

<!-- SERVICES TABLE -->
<?php
$grouped  = [];
// Порядок категорий в печатной форме
// Включает все старые коды + новые категории после реструктуризации (LOAD, GSE, AERO_SVC)
$catOrder = [
    'MAIN','PAX','BAGGAGE','IT',
    'RAMP','LOAD',       // LOAD — загрузка/центровка (СПО)
    'REQUEST',
    'DEICING',
    'GSE',               // GSE — спецтехника (ССТ): GPU, амбулифт, водовозка и др.
    'CLEANING',
    'SECURITY','AERO_SVC', // AERO_SVC — аэродромные услуги: SITA и др.
    'OTHER',
];
foreach ($items as $item) {
    $grouped[$item['category_code'] ?? 'OTHER'][] = $item;
}
$catLabels = [
    'MAIN'     => 'Main services / Основные услуги',
    'PAX'      => 'Passenger services / Пассажирские услуги',
    'BAGGAGE'  => 'Baggage / Обработка багажа',
    'IT'       => 'IT Systems / ИТ системы (DCS / CUPPS)',
    'RAMP'     => 'Ramp Handling / Рамповое обслуживание',
    'LOAD'     => 'Load Control / Загрузка и центровка',
    'REQUEST'  => 'Request services / Услуги по запросу',
    'DEICING'  => 'De-icing / Противообледенение',
    'GSE'      => 'Ground Support Equipment / Спецтехника и оборудование',
    'CLEANING' => 'Cleaning / Уборка воздушного судна',
    'SECURITY' => 'Security / Охрана',
    'AERO_SVC' => 'Aerodrome Services / Услуги аэродромной службы',
    'OTHER'    => 'Other / Прочие услуги',
];
?>
<table class="svc-tbl">
    <colgroup>
        <col class="col-name"><col class="col-rate">
        <col class="col-qty"><col class="col-unit">
        <col class="col-amt"><col class="col-total">
    </colgroup>
    <thead>
    <tr>
        <th>Airport services / Аэропортовые услуги<br>
            <span style="font-weight:normal;font-size:7pt">Type of services / Перечень услуг</span></th>
        <th>Rate/Тариф<br><span style="font-weight:normal;font-size:7pt">USD</span></th>
        <th>Qty<br><span style="font-weight:normal;font-size:7pt">Кол-во</span></th>
        <th>Unit<br><span style="font-weight:normal;font-size:7pt">Ед.</span></th>
        <th>Amount/Сумма<br><span style="font-weight:normal;font-size:7pt"><?= $cur ?></span></th>
        <th>Total/Итого<?= $isIntl ? '' : '+НДС' ?><br>
            <span style="font-weight:normal;font-size:7pt"><?= $cur ?></span></th>
    </tr>
    </thead>
    <tbody>
    <?php if (empty($items)): ?>
        <tr><td colspan="6" style="text-align:center;padding:14px;font-style:italic;">
            Нет услуг / No services added</td></tr>
    <?php else: ?>
        <?php
        $lineNo = 0; $rowIdx = 0;
        foreach ($catOrder as $catCode):
            if (empty($grouped[$catCode])) continue;
        ?>
        <tr class="cat-row">
            <td colspan="6"><?= e($catLabels[$catCode] ?? $catCode) ?></td>
        </tr>
        <?php foreach ($grouped[$catCode] as $item):
            $lineNo++; $rowIdx++;
            $hasVal = (float)$item['amount_with_vat'] > 0;
            $qty = (float)$item['quantity'];
            $qtyFmt = (fmod($qty, 1) == 0) ? number_format($qty, 0, '.', ' ') : number_format($qty, 2, '.', ' ');
        ?>
        <tr class="data-row <?= ($rowIdx % 2 == 0) ? 'even' : '' ?>">
            <td class="name">
                <span style="color:#555;font-size:7.5pt"><?= $lineNo ?>.</span>
                <?= e($item['service_name_snapshot']) ?>
                <?php if ($item['calculation_note']): ?>
                    <br><span style="color:#444;font-style:italic;font-size:7pt"><?= e($item['calculation_note']) ?></span>
                <?php endif; ?>
            </td>
            <td class="num"><?= $hasVal ? number_format((float)$item['unit_price'], 2, '.', ' ') : '—' ?></td>
            <td class="num" style="text-align:center"><?= $qtyFmt ?></td>
            <td class="ctr"><?= e($item['unit_name_snapshot']) ?></td>
            <td class="num"><?= $hasVal ? number_format((float)$item['amount_without_vat'], 2, '.', ' ') : '—' ?></td>
            <td class="num" style="font-weight:bold"><?= $hasVal ? number_format((float)$item['amount_with_vat'], 2, '.', ' ') : '—' ?></td>
        </tr>
        <?php endforeach; endforeach; ?>
    <?php endif; ?>

    <!-- VAT row -->
    <?php if ((float)$act['total_vat_amount'] > 0): ?>
    <tr class="vat-row">
        <td colspan="4" style="text-align:right;padding-right:8px;"><?= $vatLabel ?>:</td>
        <td class="num"><?= number_format((float)$act['total_vat_amount'], 2, '.', ' ') ?></td>
        <td class="num"><?= number_format((float)$act['total_vat_amount'], 2, '.', ' ') ?></td>
    </tr>
    <?php elseif ($isIntl): ?>
    <tr class="vat-row">
        <td colspan="6" style="text-align:center;color:#006400;font-weight:bold;">
            НДС не применяется / VAT not applicable — International flight (0%)
        </td>
    </tr>
    <?php endif; ?>

    <!-- TOTAL -->
    <tr class="total-row">
        <td colspan="4">ИТОГО / TOTAL — <?= e($act['currency_name']) ?> (<?= $cur ?>)</td>
        <td class="num"><?= number_format((float)$act['total_amount_without_vat'], 2, '.', ' ') ?></td>
        <td class="num"><?= number_format((float)$act['total_amount_with_vat'], 2, '.', ' ') ?></td>
    </tr>
    </tbody>
</table>

<!-- NOTE -->
<div class="note">
    <strong>Note / Примечание:</strong>
    <?= !empty($act['notes']) ? e($act['notes']) : '<span style="color:#999">—</span>' ?>
</div>

<!-- APPROVED -->
<?php if ($act['status'] === 'approved' && $approvedName): ?>
<div class="approved-banner">
    ✓ Утверждено / Approved: <?= e($approvedName) ?> — <?= $approvedDate ?>
</div>
<?php endif; ?>

<!-- SIGNATURES -->
<div class="sigs">
    <div class="sig">
        <div class="sig-title">
            Представитель «Toshkent-Humo xalqaro aeroporti» MChJ<br>
            Representative of the Airport
        </div>
        <div class="row">
            <span class="row-lbl">подпись/sig.:</span>
            <span class="row-line"></span>
        </div>
        <div class="row">
            <span class="row-lbl">Ф.И.О./Name:</span>
            <span class="row-line"></span>
            <span class="row-val"><?= e($supervisorName) ?></span>
        </div>
        <div class="row">
            <span class="row-lbl">дата/date:</span>
            <span class="row-line"></span>
            <span class="row-val"><?= $approvedDate ?? $supervisorDate ?></span>
        </div>
    </div>
    <div class="sig">
        <div class="sig-title">
            Представитель Авиакомпании<br>
            Representative of «<?= e($act['airline_name']) ?>»
        </div>
        <div class="row"><span class="row-lbl">подпись/sig.:</span><span class="row-line"></span></div>
        <div class="row"><span class="row-lbl">Ф.И.О./Name:</span><span class="row-line"></span></div>
        <div class="row"><span class="row-lbl">дата/date:</span><span class="row-line"></span></div>
    </div>
</div>

<!-- FOOTER -->
<div class="footer">
    <span>Форма А / Form A — <?= e($_ENV['APP_NAME'] ?? 'Forma A') ?></span>
    <span>Создан: <?= format_datetime($act['created_at']) ?> — <?= e($act['created_by_fullname'] ?? '—') ?></span>
    <span>Акт № <?= $actTitle ?></span>
</div>

<!-- VERIFICATION BLOCK -->
<div style="margin-top:8px;border:1.5pt solid #1a3a6b;padding:5px 8px;
            display:flex;justify-content:space-between;align-items:center;
            background:#f0f3f8;gap:10px;">
    <!-- QR код -->
    <?php if ($qrBase64): ?>
    <div style="flex-shrink:0;text-align:center">
        <img src="<?= $qrBase64 ?>" style="width:70px;height:70px;display:block">
        <div style="font-size:5.5pt;color:#555;margin-top:2px">Сканировать<br>для проверки</div>
    </div>
    <?php endif; ?>
    <!-- Текст верификации -->
    <div style="flex:1;font-size:7pt;color:#333;">
        <div style="font-weight:bold;color:#1a3a6b;font-size:8pt;margin-bottom:2px;">
            Система верификации / Document Verification
        </div>
        <div>Форма А — <?= e($_ENV['APP_NAME'] ?? 'Forma A') ?></div>
        <div style="margin-top:2px">
            <span style="color:#555;">ВКД / VCD:</span>
            <span style="font-family:monospace;font-weight:bold;letter-spacing:1.5px;color:#1a3a6b;">
                <?= $verifyCode ?>
            </span>
        </div>
        <div style="color:#888;font-size:6pt;margin-top:1px;word-break:break-all;">
            <?= $verifyUrl ?>
        </div>
    </div>
    <!-- Реквизиты акта -->
    <div style="font-size:7pt;color:#333;text-align:right;flex-shrink:0;">
        <div style="font-weight:bold"><?= e($act['act_number']) ?></div>
        <div><?= format_date($act['act_date'], 'd.m.Y') ?></div>
        <div style="color:#555"><?= e($act['currency_code']) ?></div>
        <div style="font-weight:bold;color:#1a3a6b">
            <?= number_format((float)$act['total_amount_with_vat'], 2, '.', ' ') ?>
        </div>
    </div>
</div>

</div><!-- /.page -->
</body>
</html>